from turtle import Turtle, Screen
t1 = Turtle()

sc = Screen()
sc.exitonclick()